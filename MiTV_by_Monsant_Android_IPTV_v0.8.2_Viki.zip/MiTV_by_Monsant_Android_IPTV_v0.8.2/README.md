# MiTV by Monsant — v0.8, catálogo unificado (beta)

Proyecto Android basado en MiTV 0.7, con nueva pestaña **Explorar** para películas, series, animé y doramas; manteniendo IPTV, cuatro perfiles y favoritos de TV. No es un APK: hay que compilarlo.

## Qué funciona

- Secciones de catálogo de **Películas, Series, Animé y Doramas**.
- Cuatro perfiles; el catálogo externo queda **deshabilitado en Peques** hasta contar con filtros parentales verificables. El control infantil de canales IPTV se mantiene.
- Búsqueda global, fichas, portadas, paginación y favoritos de títulos por perfil **cuando se configura una clave gratuita TMDB API v3**.
- Disponibilidad de **suscripción, gratis y con anuncios para Chile**, consultada por título en TMDB. No se inventan plataformas: si falta información se indica.
- Cada título permite guardar un **nombre de doblaje/versión preferida** y una URL HTTPS personal. La app solo abre ese enlace externo; no copia, descarga ni reproduce ilícitamente videos.
- En las fichas, las plataformas con disponibilidad de suscripción se abren mediante sus aplicaciones oficiales cuando estén instaladas. No se integran videos protegidos de Netflix, Disney+, HBO Max ni Crunchyroll.
- Sin clave TMDB, hay **ocho fichas de ejemplo**, marcadas expresamente como no verificadas. NO son el catálogo completo.
- Los servicios «Ver en MiTV» dentro de la app siguen limitados a **TV IPTV autorizada** y futuras fuentes con permiso de reproducción. No se simula disponibilidad interna.

## Conectar el catálogo real

TMDB requiere una clave de API. Desde la app: **Explorar → Conectar catálogo TMDB → Solicitar clave gratuita** (`https://www.themoviedb.org/settings/api`). Ingresar la **API key v3** en la app (no la contraseña de TMDB ni de servicios de streaming). Solo para uso personal no comercial. La clave se guarda localmente en el dispositivo y puede quitarse desde Configuración. La API requiere conexión.

**Fuente y atribución:** This product uses the TMDB API but is not endorsed or certified by TMDB. Datos y carátulas de [TMDB](https://www.themoviedb.org/). Se cumple atribución para uso no comercial de acuerdo con su documentación.

## Limitaciones conocidas

- Disponibilidad según TMDB puede ser incompleta o cambiar. No comprueba si tu cuenta tiene la película ni el doblaje disponible. Las ofertas de compra/alquiler no se presentan como incluidas en suscripción.
- En «Mis plataformas», Netflix y demás reproductores siguen siendo externos. Los títulos pueden abrir la app general (no necesariamente la ficha exacta).
- Las versiones 0.4, 0.6 y 0.7 usan otros identificadores de app; esta versión `com.monsant.mitv.catalog` **se instala por separado** y no comparte automáticamente perfiles o listas guardadas con los APK anteriores.
- Es una primera beta que todavía no se ha ejecutado ni compilado localmente; el APK debe probarse con GitHub Actions.
- No se incluyeron imágenes oficiales de Monsant ni se alteraron sus personajes aprobados.

## Compilación con GitHub Actions desde celular

1. Subir `MiTV_by_Monsant_Android_IPTV_v0.8.zip` al repositorio privado existente.
2. Reemplazar íntegramente `.github/workflows/compilar-mitv.yml` por el archivo adjunto `compilar-mitv-v08.yml`.
3. Guardar y entrar en Actions. Si la ejecución termina verde, bajar el artifact ZIP `MiTV-0.8-Catalogo-APK` y extraer `app-debug.apk`.
4. Instalar y probar desde el celular primero. Esta versión no reemplaza MiTV 0.6.

El primer paso de prueba es **Explorar** y después **Conectar TMDB**. No subas claves API ni contraseñas al repositorio.


## Correccion 0.8.1
Se corrigio el error de Kotlin en CatalogActivity.kt (linea 93): la propiedad background de ScrollView era Drawable, no el color Int de la actividad. Se usa this@CatalogActivity.background explicitamente. Esta version requiere compilacion y prueba en Android antes de considerarse validada.


## MiTV 0.8.2 · Rakuten Viki
- Integración de Rakuten Viki en Mis plataformas. Aparece sin marcar inicialmente (no se presume una suscripción). Puede consultarse su catálogo público.
- En Doramas, selector de Corea, China, Japón, Taiwán o Tailandia, y filtro opcional "En Rakuten Viki (Chile)". El filtro consulta a TMDB para recuperar el ID de Viki y sus datos de disponibilidad, sin inventar enlaces ni disponibilidad.
- Los doramas se restringen a género Drama (18) y excluyen géneros Reality, Talk y Kids para reducir programas de variedades. Esta clasificación automática no es perfecta.
- Si una ficha no tiene proveedor confirmado en TMDB, MiTV explica que esa ausencia NO es prueba de indisponibilidad. En Doramas, se puede buscar el título en Viki: copia el título y abre su app oficial, o su sitio web si no está instalada.
- MiTV no reproduce ni descarga material protegido de Viki; Viki mantiene su propia sesión y licencia por país.
- Paquete de Android separado de 0.8.1 para evitar conflictos de firma de APK de depuración; no migra ajustes ni TMDB API de la versión anterior.
