package com.monsant.mitv

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/** Catálogo MiTV 0.8: TMDB (si el usuario configura su clave gratuita), guardados y fichas.
 * Los datos de disponibilidad se consultan para Chile; jamás se presuponen plataformas.
 * Reproducción protegida: siempre dentro de su servicio oficial.
 */
class CatalogActivity : Activity() {
    private val background = Color.rgb(17, 13, 30)
    private val purple = Color.rgb(44, 30, 67)
    private val accent = Color.rgb(209, 180, 254)
    private val white = Color.rgb(250, 248, 255)
    private val muted = Color.rgb(196, 182, 212)
    private val prefs by lazy { getSharedPreferences("mitv_catalog_v08", MODE_PRIVATE) }
    private val profilePrefs by lazy { getSharedPreferences("mitv_v04", MODE_PRIVATE) }
    private val profile: Int get() = profilePrefs.getInt("current_profile", 0)
    private lateinit var container: LinearLayout
    private var currentCategory = "Películas"
    private var query = ""
    private var page = 1
    private var onlyMine = false
    private var onlyViki = false
    private var dramaCountry = "KR"
    private var lastItems = mutableListOf<CatalogTitle>()
    private val providersCache = ConcurrentHashMap<String, List<Provider>>()
    private var currentGrid: GridLayout? = null
    private var currentScreen = ""
    private val providersPending = ConcurrentHashMap.newKeySet<String>()

    data class CatalogTitle(
        val id: Int, val type: String, val title: String, val overview: String,
        val year: String, val poster: String, val example: Boolean = false
    ) {
        val key: String get() = "$type:$id"
        fun toJson(): JSONObject = JSONObject().put("id", id).put("type", type)
            .put("title", title).put("overview", overview).put("year", year)
            .put("poster", poster).put("example", example)
    }
    data class Provider(val name: String, val kind: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (profile == 3) {
            AlertDialog.Builder(this).setTitle("Catálogo infantil protegido")
                .setMessage("El catálogo externo no está habilitado para Peques hasta tener filtros de edad y títulos aprobados por adultos. Los canales infantiles autorizados siguen disponibles en TV en vivo.")
                .setPositiveButton("Volver") { _, _ -> finish() }
                .setOnCancelListener { finish() }.show()
        } else showCategories()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int = purple) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(16).toFloat()
    }
    private fun label(value: String, size: Float = 15f, bold: Boolean = false, color: Int = white) =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(5), dp(5), dp(5), dp(5))
        }
    private fun button(value: String, action: () -> Unit): Button = Button(this).apply {
        text = value; isAllCaps = false; textSize = 15f; setTextColor(white)
        background = bg(); minHeight = dp(52); isFocusable = true
        setOnClickListener { action() }
    }
    private fun addButton(value: String, action: () -> Unit) {
        container.addView(button(value, action), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }
    private fun header(title: String, subtitle: String) {
        currentScreen = title
        val s = ScrollView(this).apply { setBackgroundColor(this@CatalogActivity.background); isFillViewport = true }
        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(15), dp(16), dp(30))
        }
        s.addView(container); setContentView(s)
        container.addView(label("MiTV  ·  by Monsant", 15f, true, accent))
        container.addView(label(title, 27f, true))
        container.addView(label(subtitle, 13f, false, muted))
    }
    private fun apiKey(): String = prefs.getString("tmdb_api_key", "") ?: ""
    private fun showCategories() {
        currentGrid = null
        header("¿Qué se te antoja ver? 🍿", "Explora todo en un mismo catálogo · disponibilidad consultada para Chile")
        listOf("Películas", "Series", "Animé", "Doramas").forEach { cat ->
            addButton("${when (cat) { "Películas" -> "🎬"; "Series" -> "📺"; "Animé" -> "🌸"; else -> "💕" }}  $cat") {
                currentCategory = cat; query = ""; page = 1; onlyViki = false; loadCatalog()
            }
        }
        addButton("🔎 Buscar en todo el catálogo") { askSearch() }
        addButton("💜 Mis títulos y versiones favoritas") { showSaved() }
        addButton("⚙️ Conectar catálogo de películas y series (TMDB)") { showSettings() }
        container.addView(label("TV en vivo continúa en el inicio de MiTV. El catálogo permite explorar y guardar títulos; el contenido protegido se reproduce desde su servicio oficial.", 12f, false, muted))
        addButton("← Volver a MiTV") { finish() }
    }
    private fun askSearch() {
        val input = EditText(this).apply {
            hint = "Título de película, serie o animé"; setSingleLine(true)
            setText(query); setSelection(text.length)
        }
        AlertDialog.Builder(this).setTitle("Buscar en MiTV")
            .setView(input).setNegativeButton("Cancelar", null)
            .setPositiveButton("Buscar") { _, _ ->
                query = input.text.toString().trim(); page = 1; onlyViki = false
                if (query.isNotBlank()) { currentCategory = "Búsqueda"; loadCatalog() }
            }.show()
    }
    private fun showSettings() {
        header("Conectar catálogo TMDB", "Necesario para cargar fichas reales y consultar plataformas en Chile")
        container.addView(label("Para uso personal no comercial puedes solicitar una clave de TMDB. MiTV guarda la clave únicamente en este dispositivo y no solicita contraseñas de Netflix, YouTube ni Disney+.", 14f))
        addButton("1. Solicitar clave gratuita en TMDB") { open("https://www.themoviedb.org/settings/api") }
        addButton("2. Pegar mi clave API v3") {
            val input = EditText(this).apply {
                hint = "API key v3 de TMDB"; setSingleLine(true)
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            }
            AlertDialog.Builder(this).setTitle("Clave de catálogo TMDB")
                .setView(input).setNegativeButton("Cancelar", null)
                .setPositiveButton("Guardar") { _, _ ->
                    val key = input.text.toString().trim()
                    if (key.matches(Regex("[a-fA-F0-9]{32}"))) {
                        prefs.edit().putString("tmdb_api_key", key).apply()
                        Toast.makeText(this, "Clave guardada en este dispositivo", Toast.LENGTH_SHORT).show()
                        currentCategory = "Películas"; query = ""; page = 1; loadCatalog()
                    } else notice("Clave no válida", "Pega la clave API v3 de 32 caracteres que TMDB asigna a tu cuenta; no compartas contraseñas de tus plataformas.")
                }.show()
        }
        if (apiKey().isNotBlank()) addButton("Olvidar clave de catálogo de este dispositivo") {
            prefs.edit().remove("tmdb_api_key").apply(); providersCache.clear(); showSettings()
        }
        container.addView(label("Fuente: datos y carátulas de TMDB (no avala MiTV). La disponibilidad por región puede variar y se debe confirmar en el proveedor.", 12f, false, muted))
        addButton("← Inicio del catálogo") { showCategories() }
    }
    private fun loadCatalog() {
        header(currentCategory, if (query.isBlank()) "Portadas, fichas, favoritos y dónde verlo" else "Resultados para «$query»")
        addButton("← Categorías") { showCategories() }
        addButton("🔎 Buscar otro título") { askSearch() }
        addButton(if (onlyMine) "☑ Solo mis plataformas · mostrar todo" else "☐ Solo mis plataformas") {
            onlyMine = !onlyMine; renderGrid()
        }
        if (currentCategory == "Doramas" && query.isBlank()) {
            val regions = linkedMapOf("KR" to "Corea del Sur", "CN" to "China", "JP" to "Japón", "TW" to "Taiwán", "TH" to "Tailandia")
            addButton("🌏 País de origen: ${regions[dramaCountry] ?: "Corea del Sur"}") {
                val values = regions.entries.toList()
                AlertDialog.Builder(this).setTitle("Explorar dramas por país")
                    .setItems(values.map { it.value }.toTypedArray()) { _, idx ->
                        dramaCountry = values[idx].key; page = 1; loadCatalog()
                    }.show()
            }
            addButton(if (onlyViki) "☑ En Rakuten Viki (Chile) · mostrar todos" else "☐ Mostrar doramas en Rakuten Viki (Chile)") {
                onlyViki = !onlyViki; onlyMine = false; page = 1; loadCatalog()
            }
            container.addView(label("Mostramos dramas de ficción. El filtro de Viki depende de los datos de TMDB para Chile; que un título no figure allí NO significa que no esté en Viki.", 12f, false, muted))
            addButton("🔎 Abrir catálogo oficial de Rakuten Viki") { openVikiHome() }
        }
        val message = label("Preparando catálogo...", 14f, false, muted)
        container.addView(message)
        currentGrid = GridLayout(this).apply { columnCount = if (resources.configuration.screenWidthDp >= 700) 4 else 2 }
        container.addView(currentGrid)
        if (apiKey().isBlank()) {
            message.text = "Vista de ejemplo: conecta TMDB para cargar resultados reales y etiquetas de disponibilidad en Chile. Estos títulos no tienen plataforma verificada."
            lastItems = demoItems().filter {
                query.isBlank() && currentCategory == itCategory(it) || query.isNotBlank() && it.title.contains(query, true)
            }.toMutableList()
            renderGrid()
            addButton("Conectar catálogo real de TMDB") { showSettings() }
            return
        }
        val selectedCategory = currentCategory
        val selectedQuery = query
        Thread {
            try {
                val selectedOnlyViki = selectedCategory == "Doramas" && onlyViki
                val providerId = if (selectedOnlyViki) lookupVikiIdInChile() else null
                if (selectedOnlyViki && providerId == null) {
                    runOnUiThread {
                        message.text = "TMDB no informa a Rakuten Viki como proveedor de TV para Chile. Esto no significa que Viki no tenga doramas disponibles: usa «Abrir catálogo oficial de Rakuten Viki» y busca allí."
                        lastItems = mutableListOf(); renderGrid()
                    }
                    return@Thread
                }
                val endpoint = when {
                    selectedQuery.isNotBlank() -> "search/multi?query=${Uri.encode(selectedQuery)}&include_adult=false"
                    selectedCategory == "Películas" -> "movie/popular?"
                    selectedCategory == "Series" -> "tv/popular?"
                    selectedCategory == "Animé" -> "discover/tv?with_original_language=ja&with_genres=16&sort_by=popularity.desc"
                    else -> "discover/tv?with_origin_country=${Uri.encode(dramaCountry)}&with_genres=18&without_genres=10764,10767,10762&sort_by=popularity.desc" +
                        (if (providerId != null) "&watch_region=CL&with_watch_providers=$providerId" else "")
                }
                val json = fetchJson(endpoint + "&language=es-CL&page=$page")
                val array = json.getJSONArray("results")
                val items = mutableListOf<CatalogTitle>()
                for (i in 0 until array.length()) {
                    val obj = array.optJSONObject(i) ?: continue
                    val type = obj.optString("media_type").ifBlank { if (selectedCategory == "Películas") "movie" else "tv" }
                    if (type !in listOf("movie", "tv")) continue
                    val title = (if (type == "movie") obj.optString("title") else obj.optString("name")).ifBlank { "Sin título" }
                    val date = if (type == "movie") obj.optString("release_date") else obj.optString("first_air_date")
                    items.add(CatalogTitle(obj.optInt("id"), type, title,
                        obj.optString("overview"), date.take(4), obj.optString("poster_path")))
                }
                runOnUiThread {
                    message.text = "${items.size} títulos · Página $page · Disponibilidad consultada para Chile"
                    lastItems = items
                    renderGrid()
                    if (items.size >= 18) addButton("Ver más títulos →") { page++; loadCatalog() }
                }
            } catch (e: Exception) {
                runOnUiThread { message.text = "No se pudo cargar el catálogo: ${e.localizedMessage ?: "comprueba la conexión y la clave TMDB"}" }
            }
        }.start()
    }
    /** Uses TMDB's provider list, rather than assuming a fixed numeric provider ID. */
    private fun lookupVikiIdInChile(): Int? {
        val response = fetchJson("watch/providers/tv?language=es-CL&watch_region=CL")
        val results = response.optJSONArray("results") ?: return null
        for (i in 0 until results.length()) {
            val provider = results.optJSONObject(i) ?: continue
            if (provider.optString("provider_name").contains("Viki", true)) {
                return provider.optInt("provider_id").takeIf { it > 0 }
            }
        }
        return null
    }

    private fun itCategory(item: CatalogTitle): String = when (item.id) {
        -1, -2 -> "Películas"
        -3, -4 -> "Series"
        -5, -6 -> "Animé"
        else -> "Doramas"
    }
    private fun demoItems() = listOf(
        CatalogTitle(-1,"movie","El increíble castillo vagabundo","Ejemplo para probar tus versiones favoritas.","2004","",true),
        CatalogTitle(-2,"movie","El viaje de Chihiro","Ejemplo de catálogo.","2001","",true),
        CatalogTitle(-3,"tv","Stranger Things","Ejemplo de serie.","2016","",true),
        CatalogTitle(-4,"tv","Dark","Ejemplo de serie.","2017","",true),
        CatalogTitle(-5,"tv","Frieren","Ejemplo de animé.","2023","",true),
        CatalogTitle(-6,"tv","Spy × Family","Ejemplo de animé.","2022","",true),
        CatalogTitle(-7,"tv","Propuesta laboral","Ejemplo de dorama coreano.","2022","",true),
        CatalogTitle(-8,"tv","Aterrizaje de emergencia en tu corazón","Ejemplo de dorama coreano.","2019","",true)
    )
    private fun renderGrid() {
        val grid = currentGrid ?: return
        grid.removeAllViews()
        val cols = grid.columnCount
        val w = (resources.displayMetrics.widthPixels / resources.displayMetrics.density).toInt()
        val available = (w - 42 - (cols - 1) * 8) / cols
        val items = if (!onlyMine) lastItems else lastItems.filter { title ->
            providersCache[title.key]?.any { provider ->
                provider.kind == "Incluido" && selectedPlatform(provider.name)
            } == true
        }
        if (items.isEmpty()) grid.addView(label(if (onlyMine) "Sin plataformas confirmadas para este filtro. Desactívalo o consulta disponibilidad." else "Sin resultados.", 14f, false, muted))
        items.forEach { t ->
            val tile = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg() ; setPadding(dp(5), dp(6), dp(5), dp(9)) }
            val poster = ImageView(this).apply { setBackgroundColor(Color.rgb(79, 55, 106)); scaleType = ImageView.ScaleType.CENTER_CROP }
            tile.addView(poster, LinearLayout.LayoutParams(-1, dp(if (cols == 4) 205 else 190)))
            if (t.poster.startsWith("/")) loadPoster(t.poster, poster)
            else tile.addView(label("🎬 Vista de ejemplo", 11f, false, accent))
            tile.addView(label(t.title, 15f, true))
            tile.addView(label(t.year.ifBlank { "Sin año" }, 11f, false, muted))
            val providerLabel = label(if (t.example) "Plataforma no verificada" else "Consultando Chile...", 11f, false, accent)
            tile.addView(providerLabel)
            tile.addView(button("Ver ficha") { showDetail(t) }, LinearLayout.LayoutParams(-1, dp(48)))
            val lp = GridLayout.LayoutParams().apply {
                width = dp(available.coerceAtLeast(100)); height = -2
                setMargins(dp(3), dp(5), dp(3), dp(5))
            }
            grid.addView(tile, lp)
            if (!t.example) {
                val wasCached = providersCache.containsKey(t.key)
                loadProviders(t) { providers ->
                    providerLabel.text = providerText(providers)
                    if (onlyMine && !wasCached) renderGrid()
                }
            }
        }
    }
    private fun selectedPlatform(name: String): Boolean {
        val service = when {
            name.contains("Netflix", true) -> "Netflix"
            name.contains("Crunchyroll", true) -> "Crunchyroll"
            name.contains("Viki", true) -> "Rakuten Viki"
            name.contains("Disney", true) -> "Disney+"
            name.contains("Max", true) || name.contains("HBO", true) -> "HBO Max"
            name.contains("YouTube", true) -> "YouTube Premium"
            else -> return false
        }
        return profilePrefs.getBoolean("platform_${profile}_$service", true)
    }
    private fun providerText(values: List<Provider>): String {
        if (values.isEmpty()) return "TMDB no registra una plataforma para Chile; puedes consultar Viki u otros servicios"
        return values.take(3).joinToString(" · ") { "${if (it.kind == "Incluido") "En" else it.kind + ":"} ${it.name}" }
    }
    private fun loadProviders(title: CatalogTitle, onDone: (List<Provider>) -> Unit) {
        val cached = providersCache[title.key]
        if (cached != null) { onDone(cached); return }
        if (apiKey().isBlank() || title.example) { onDone(emptyList()); return }
        if (!providersPending.add(title.key)) return
        Thread {
            val p = try {
                val json = fetchJson("${title.type}/${title.id}/watch/providers")
                val cl = json.optJSONObject("results")?.optJSONObject("CL")
                val results = mutableListOf<Provider>()
                for ((field,kind) in listOf("flatrate" to "Incluido", "free" to "Gratis", "ads" to "Con anuncios")) {
                    val arr = cl?.optJSONArray(field) ?: continue
                    for (i in 0 until arr.length()) {
                        val name = arr.optJSONObject(i)?.optString("provider_name") ?: continue
                        if (results.none { it.name == name }) results.add(Provider(name, kind))
                    }
                }
                results
            } catch (_: Exception) { emptyList() }
            providersCache[title.key] = p
            providersPending.remove(title.key)
            runOnUiThread { onDone(p) }
        }.start()
    }
    private fun showDetail(item: CatalogTitle) {
        currentGrid = null
        header(item.title, "${if(item.type == "movie") "Película" else "Serie"} · ${item.year} · Chile")
        val panel = label("${item.overview.ifBlank { "Sin sinopsis disponible." }}", 14f)
        container.addView(panel)
        val available = label(if (item.example) "Ficha de ejemplo. La plataforma no está verificada." else "Consultando disponibilidad para Chile...", 14f, false, accent)
        container.addView(available)
        if (!item.example) {
            val detailArea = container
            loadProviders(item) { providers ->
                if (currentScreen == item.title && container === detailArea) {
                    available.text = if (providers.isEmpty())
                        "TMDB no registra disponibilidad para Chile. Esto NO significa que el título no exista en Viki u otra plataforma."
                        else providerText(providers)
                    providers.filter { it.kind == "Incluido" }.distinctBy { it.name }.forEach { provider ->
                        addButton("Abrir ${provider.name} (app oficial)") { openPlatform(provider.name) }
                    }
                    if (currentCategory == "Doramas" || providers.any { it.name.contains("Viki", true) }) {
                        val verified = providers.any { it.name.contains("Viki", true) }
                        addButton(if (verified) "🔎 Buscar este título en Rakuten Viki" else "🔎 Consultar este título en Viki (sin confirmar)") {
                            searchOnViki(item.title)
                        }
                    }
                }
            }
        }
        addButton(if (isFavorite(item)) "★ Quitar de mis títulos favoritos" else "☆ Guardar en mis títulos favoritos") {
            toggleFavorite(item); showDetail(item)
        }
        val savedUrl = favoriteUrl(item)
        if (savedUrl.isNotEmpty()) {
            container.addView(label("💜 Mi versión favorita: ${prefs.getString(versionKey(item) + "_label", "Doblaje preferido")}", 14f, true, accent))
            addButton("Abrir mi versión guardada") { open(savedUrl) }
        }
        addButton("💜 Guardar / cambiar enlace y doblaje favorito") { saveVersionDialog(item) }
        container.addView(label("Los enlaces guardados son referencias personales. MiTV no descarga ni redistribuye videos de terceros. Reproducción integrada solo para fuentes autorizadas.", 12f, false, muted))
        addButton("← Volver al catálogo") { loadCatalog() }
    }
    private fun favoritesKey() = "fav_titles_$profile"
    private fun readFavorites(): MutableMap<String, CatalogTitle> {
        val result = mutableMapOf<String, CatalogTitle>()
        try {
            val arr = JSONArray(prefs.getString(favoritesKey(), "[]"))
            for (i in 0 until arr.length()) {
                val j = arr.getJSONObject(i)
                val t = CatalogTitle(j.getInt("id"), j.getString("type"), j.getString("title"),
                    j.optString("overview"), j.optString("year"), j.optString("poster"), j.optBoolean("example"))
                result[t.key] = t
            }
        } catch (_: Exception) { }
        return result
    }
    private fun isFavorite(t: CatalogTitle) = readFavorites().containsKey(t.key)
    private fun toggleFavorite(t: CatalogTitle) {
        val items = readFavorites()
        if (items.containsKey(t.key)) items.remove(t.key) else items[t.key] = t
        val arr = JSONArray(); items.values.forEach { arr.put(it.toJson()) }
        prefs.edit().putString(favoritesKey(), arr.toString()).apply()
    }
    private fun versionKey(t: CatalogTitle) = "version_${profile}_${t.key}"
    private fun favoriteUrl(t: CatalogTitle) = prefs.getString(versionKey(t), "") ?: ""
    private fun saveVersionDialog(t: CatalogTitle) {
        val fields = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), 0, dp(18), 0)
        }
        val name = EditText(this).apply {
            hint = "Ej.: doblaje latino antiguo"; setSingleLine(true)
            setText(prefs.getString(versionKey(t) + "_label", ""))
        }
        val field = EditText(this).apply {
            hint = "https://... enlace de tu versión preferida"
            setSingleLine(true); setText(favoriteUrl(t))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        fields.addView(name)
        fields.addView(field)
        AlertDialog.Builder(this).setTitle("Mi versión favorita")
            .setMessage("Escribe el doblaje que prefieres y guarda un enlace de la publicación original. MiTV no descarga ni copia el video.")
            .setView(fields).setNegativeButton("Cancelar", null)
            .setNeutralButton("Eliminar") { _, _ -> prefs.edit().remove(versionKey(t)).remove(versionKey(t) + "_label").apply(); showDetail(t) }
            .setPositiveButton("Guardar") { _, _ ->
                val value = field.text.toString().trim()
                val parsed = Uri.parse(value)
                if (value.isBlank() || (parsed.scheme == "https" && !parsed.host.isNullOrBlank())) {
                    prefs.edit().putString(versionKey(t), value)
                        .putString(versionKey(t) + "_label", name.text.toString().trim().take(80)).apply()
                    showDetail(t)
                } else notice("Enlace inválido", "Utiliza una URL HTTPS completa de la publicación original.")
            }.show()
    }
    private fun showSaved() {
        currentGrid = null
        header("Mis favoritos 💜", "Cada perfil tiene su propia lista")
        val items = readFavorites().values.sortedBy { it.title }
        if (items.isEmpty()) container.addView(label("Todavía no has guardado títulos. Explora el catálogo y toca ☆.", 15f, false, muted))
        items.forEach { t -> addButton("★ ${t.title}${if (favoriteUrl(t).isNotBlank()) " · 💜 Mi versión" else ""}") { showDetail(t) } }
        addButton("← Catálogo") { showCategories() }
    }
    private fun loadPoster(path: String, view: ImageView) {
        val key = path
        view.tag = key
        Thread {
            try {
                val conn = (URL("https://image.tmdb.org/t/p/w342$path").openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000; readTimeout = 8000
                }
                try {
                    if (conn.responseCode != 200) return@Thread
                    val bytes = conn.inputStream.use { it.readBytes() }
                    if (bytes.size > 800_000) return@Thread
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return@Thread
                    runOnUiThread { if (view.tag == key) view.setImageBitmap(bmp) }
                } finally { conn.disconnect() }
            } catch (_: Exception) { }
        }.start()
    }
    private fun fetchJson(endpoint: String): JSONObject {
        val normalized = if (endpoint.contains("?")) "$endpoint&" else "$endpoint?"
        val complete = "https://api.themoviedb.org/3/$normalized" + "api_key=${Uri.encode(apiKey())}"
        val conn = (URL(complete).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12000; readTimeout = 12000
            setRequestProperty("Accept", "application/json")
        }
        try {
            if (conn.responseCode !in 200..299) throw IllegalStateException("TMDB respondió ${conn.responseCode}. Revisa la clave o tu conexión.")
            return JSONObject(conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
        } finally { conn.disconnect() }
    }
    private fun openVikiHome() {
        openPlatform("Rakuten Viki")
    }

    private fun searchOnViki(title: String) {
        try {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Título para buscar en Viki", title))
            Toast.makeText(this, "Título copiado: pégalo en la búsqueda de Viki", Toast.LENGTH_LONG).show()
        } catch (_: Exception) { }
        openVikiHome()
    }

    private fun openPlatform(name: String) {
        val pair = when {
            name.contains("Netflix", true) -> "com.netflix.mediaclient" to "https://www.netflix.com/"
            name.contains("Crunchyroll", true) -> "com.crunchyroll.crunchyroid" to "https://www.crunchyroll.com/"
            name.contains("Viki", true) -> "com.viki.android" to "https://www.viki.com/?locale=es"
            name.contains("Disney", true) -> "com.disney.disneyplus" to "https://www.disneyplus.com/"
            name.contains("HBO", true) || name.contains("Max", true) -> "com.wbd.stream" to "https://www.hbomax.com/"
            name.contains("YouTube", true) -> "com.google.android.youtube" to "https://www.youtube.com/"
            else -> "" to ""
        }
        if (pair.first.isBlank()) { notice("Proveedor", "No tenemos enlace directo verificado a este proveedor. Busca el título en su aplicación oficial."); return }
        val intent = packageManager.getLeanbackLaunchIntentForPackage(pair.first)
            ?: packageManager.getLaunchIntentForPackage(pair.first)
        if (intent != null) {
            try { startActivity(intent); return } catch (_: Exception) { }
        }
        AlertDialog.Builder(this).setTitle("Abrir ${name}")
            .setMessage("No detectamos la aplicación oficial compatible. ¿Abrir su sitio web?")
            .setPositiveButton("Abrir web") { _, _ -> open(pair.second) }
            .setNegativeButton("Cancelar", null).show()
    }
    private fun open(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { notice("No se pudo abrir", "Revisa tu navegador o la aplicación oficial.") }
    }
    private fun notice(title: String, body: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(body)
            .setPositiveButton("Entendido", null).show()
    }
    @Deprecated("Legacy back handler")
    override fun onBackPressed() { if (currentScreen == "¿Qué se te antoja ver? 🍿") finish() else showCategories() }
}
