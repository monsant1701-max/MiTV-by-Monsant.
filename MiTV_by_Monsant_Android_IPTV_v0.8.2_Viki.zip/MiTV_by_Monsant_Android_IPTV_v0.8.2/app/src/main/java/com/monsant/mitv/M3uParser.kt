package com.monsant.mitv

data class TvChannel(
    val name: String,
    val url: String,
    val group: String = "Otros",
    val logo: String = ""
) {
    val id: String get() = url
}

object M3uParser {
    private val attribute = Regex("""([A-Za-z0-9_-]+)="([^"]*)"""")
    fun parse(text: String): List<TvChannel> {
        val result = mutableListOf<TvChannel>()
        val seen = mutableSetOf<String>()
        var name = ""
        var group = "Otros"
        var logo = ""
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.startsWith("#EXTINF", ignoreCase = true)) {
                val meta = attribute.findAll(line).associate { it.groupValues[1] to it.groupValues[2] }
                name = line.substringAfterLast(',', "Canal").trim().ifEmpty { meta["tvg-name"] ?: "Canal" }
                group = meta["group-title"]?.ifBlank { "Otros" } ?: "Otros"
                logo = meta["tvg-logo"]?.takeIf { it.startsWith("https://") } ?: ""
            } else if (line.isNotEmpty() && !line.startsWith("#")) {
                if ((line.startsWith("https://") || line.startsWith("http://")) && seen.add(line)) {
                    result += TvChannel(name.ifBlank { "Canal ${result.size + 1}" }, line, group, logo)
                    if (result.size >= 1200) break
                }
                name = ""; group = "Otros"; logo = ""
            }
        }
        return result
    }
}
