package com.monsant.mitv

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.text.TextWatcher
import android.text.Editable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private lateinit var store: MiTVStore
    private lateinit var pins: PinManager
    private lateinit var area: LinearLayout
    private var listArea: LinearLayout? = null
    private var search = ""
    private var onlyFavorites = false
    private var categoryFilter = "Todos"
    private var hideProblematic = false
    private var screen = "profiles"
    private val bg = Color.rgb(17, 13, 30)
    private val card = Color.rgb(40, 28, 61)
    private val lilac = Color.rgb(206, 173, 255)
    private val white = Color.rgb(250, 246, 255)
    private val muted = Color.rgb(199, 184, 216)
    private val names = listOf("Monse", "Anto", "Giss", "Santi", "Dom", "Kiara", "Canela", "Blue", "Rocky", "Cody")
    private val emoji = mapOf("Monse" to "💜", "Anto" to "🎧", "Giss" to "🌼", "Santi" to "🎸", "Dom" to "🎮", "Kiara" to "🐈‍⬛", "Canela" to "🐶", "Blue" to "🦜", "Rocky" to "🐕", "Cody" to "🐹")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = MiTVStore(this)
        pins = PinManager(this)
        showProfiles()
    }
    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()
    private fun roundedBg(color: Int, radius: Int = 18): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun space(n: Int) { area.addView(View(this), LinearLayout.LayoutParams(1, dp(n))) }
    private fun text(s: String, size: Float = 17f, bold: Boolean = false, color: Int = white): TextView {
        return TextView(this).apply {
            this.text = s; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(4), dp(5), dp(4), dp(5))
        }
    }
    private fun startScreen(title: String, subtitle: String) {
        screen = title
        val scroll = ScrollView(this).apply { isFillViewport = true; setBackgroundColor(bg) }
        area = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(30))
            isFocusableInTouchMode = true
        }
        scroll.addView(area)
        setContentView(scroll)
        area.addView(text("MiTV  ·  by Monsant", 15f, true, lilac))
        space(8)
        area.addView(text(title, 29f, true))
        area.addView(text(subtitle, 14f, false, muted))
        space(17)
    }
    private fun makeButton(title: String, color: Int = card, action: () -> Unit): Button {
        return Button(this).apply {
            text = title; textSize = 16f; isAllCaps = false
            setTextColor(white); minHeight = dp(54)
            background = roundedBg(color)
            setPadding(dp(12), dp(9), dp(12), dp(9))
            isFocusable = true
            setOnFocusChangeListener { _, focused ->
                background = roundedBg(if (focused) Color.rgb(114, 72, 156) else color)
                if (focused) scaleX = 1.025f else scaleX = 1f
                if (focused) scaleY = 1.025f else scaleY = 1f
            }
            setOnClickListener { action() }
        }
    }
    private fun button(title: String, action: () -> Unit) {
        val b = makeButton(title, card, action)
        val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) }
        area.addView(b, lp)
    }
    private fun subhead(s: String) { space(12); area.addView(text(s, 20f, true, lilac)); space(4) }
    private fun inform(title: String, message: String) = AlertDialog.Builder(this)
        .setTitle(title).setMessage(message).setPositiveButton("Entendido", null).show()
    private fun inputDialog(title: String, hint: String, initial: String = "", onApply: (String) -> Unit) {
        val input = EditText(this).apply {
            setSingleLine(true); setText(initial); setSelection(initial.length); this.hint = hint
            setPadding(dp(16), dp(15), dp(16), dp(15))
        }
        AlertDialog.Builder(this).setTitle(title).setView(input)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Aceptar") { _, _ -> onApply(input.text.toString().trim()) }.show()
    }
    private fun pinDialog(title: String, onCorrect: () -> Unit) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "PIN de adulto"; setSingleLine(true)
        }
        AlertDialog.Builder(this).setTitle(title).setView(input)
            .setNegativeButton("Cancelar", null).setPositiveButton("Comprobar") { _, _ ->
                if (pins.check(input.text.toString())) onCorrect()
                else Toast.makeText(this, "PIN incorrecto", Toast.LENGTH_LONG).show()
            }.show()
    }
    private fun adultOnly(action: () -> Unit) {
        if (store.currentProfile == 3) pinDialog("Solo adultos", action) else action()
    }
    private fun showProfiles() {
        startScreen("¿Quién anda ahí? 👀", "Cuatro perfiles, diez avatares Monsant. Elige el tuyo.")
        for (i in 0..3) {
            button("${emoji[store.avatar(i)] ?: "✨"}  ${store.profileName(i)} · ${store.avatar(i)}${if (i==3) " · infantil" else ""}") {
                if (i==3 && !pins.configured) {
                    inform("Falta el PIN", "Un adulto debe configurar el PIN antes de utilizar Peques.")
                } else { store.currentProfile = i; showHome() }
            }
            button("  ✎ Cambiar nombre o avatar de ${store.profileName(i)}") {
                adultOnly {
                    AlertDialog.Builder(this).setTitle("Personalizar perfil")
                        .setItems(arrayOf("Cambiar nombre", "Elegir avatar")) { _, which ->
                            if (which == 0) inputDialog("Nombre del perfil", "Nombre", store.profileName(i)) { value ->
                                if (value.isNotBlank()) { store.setProfileName(i, value.take(24)); showProfiles() }
                            }
                            else AlertDialog.Builder(this).setTitle("¿Quién quieres ser hoy?")
                                .setItems(names.toTypedArray()) { _, chosen -> store.setAvatar(i, names[chosen]); showProfiles() }.show()
                        }.show()
                }
            }
            space(8)
        }
        button("🔒 Configurar PIN infantil") { adultOnly { configurePin() } }
        area.addView(text("Los avatares son provisionales. Se reemplazarán por las ilustraciones oficiales de Monsant.", 12f, false, muted))
    }
    private fun configurePin() {
        val update: () -> Unit = {
            val input = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
                hint = "Elige de 4 a 6 dígitos"; setSingleLine(true)
            }
            AlertDialog.Builder(this).setTitle("PIN infantil").setView(input)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Guardar") { _, _ ->
                    val pin = input.text.toString()
                    if (pin.matches(Regex("[0-9]{4,6}"))) {
                        pins.create(pin)
                        Toast.makeText(this, "PIN configurado", Toast.LENGTH_SHORT).show()
                    } else inform("PIN no guardado", "Debe tener de 4 a 6 números.")
                }.show()
        }
        if (pins.configured) pinDialog("PIN actual para cambiarlo", update) else update()
    }
    private fun showHome() {
        startScreen("Hola, ${store.profileName(store.currentProfile)} 🍿", "${store.avatar(store.currentProfile)} · ¿Qué vemos hoy?")
        button("🎬 Explorar · Películas, Series, Animé y Doramas") {
            if (store.currentProfile == 3) inform("Perfil Peques", "El catálogo externo permanecerá desactivado hasta tener filtros parentales verificados. TV infantil sigue disponible con canales aprobados.")
            else startActivity(Intent(this, CatalogActivity::class.java))
        }
        button("📺 TV en vivo · IPTV") { search = ""; onlyFavorites = false; showTelevision() }
        if (store.currentProfile != 3) {
            button("🎬 Mis plataformas · Netflix, Viki y más") { showPlatforms() }
        }
        button("⭐ Mis canales favoritos") { search = ""; onlyFavorites = true; showTelevision() }
        button("👤 Cambiar perfil") { adultOnly { showProfiles() } }
        if (store.currentProfile != 3) button("🔒 PIN y controles infantiles") { configurePin() }
        area.addView(text("TV en vivo utiliza listas M3U: cada señal puede estar caída, restringida por región o no permitir reproducción externa. Las plataformas de pago siguen abriendo sus aplicaciones oficiales.", 13f, false, muted))
    }
    private data class StreamingService(val name: String, val url: String, val packages: List<String>)
    private val streamingServices = listOf(
        StreamingService("Netflix", "https://www.netflix.com/", listOf("com.netflix.mediaclient")),
        StreamingService("Crunchyroll", "https://www.crunchyroll.com/", listOf("com.crunchyroll.crunchyroid")),
        StreamingService("Rakuten Viki", "https://www.viki.com/?locale=es", listOf("com.viki.android")),
        StreamingService("Disney+", "https://www.disneyplus.com/", listOf("com.disney.disneyplus")),
        StreamingService("HBO Max", "https://www.hbomax.com/", listOf("com.wbd.stream", "com.hbo.hbonow")),
        StreamingService("YouTube Premium", "https://www.youtube.com/", listOf("com.google.android.youtube.tv", "com.google.android.youtube"))
    )
    private fun showPlatforms() {
        if (store.currentProfile == 3) { showHome(); return }
        startScreen("Mis plataformas", "Abre los servicios oficiales usando tus sesiones existentes. MiTV no guarda contraseñas.")
        streamingServices.forEach { service ->
            val on = store.platformEnabled(service.name, store.currentProfile)
            button("${if (on) "☑" else "☐"} ${service.name} · ${if (on) "Activada" else "Oculta"}") {
                store.setPlatformEnabled(service.name, store.currentProfile, !on)
                showPlatforms()
            }
            if (on) button("   ▶ Abrir aplicación oficial: ${service.name}") { launchService(service) }
            if (service.name == "Rakuten Viki") button("   🔎 Explorar doramas en Viki") { launchService(service) }
            if (on && service.name == "YouTube Premium") button("   🔎 Buscar en YouTube") {
                inputDialog("Buscar en YouTube", "Videos, canales o películas oficiales") { query ->
                    if (query.isNotBlank()) searchYouTube(query)
                }
            }
        }
        area.addView(text("Abrir una plataforma no reproduce su catálogo dentro de MiTV. Cada servicio administra su sesión, perfil y reproductor. El buscador universal sigue pendiente.", 13f, false, muted))
        button("← Volver") { showHome() }
    }

    private fun launchService(service: StreamingService) {
        // Android TV usa intents LEANBACK; Android para teléfono usa intent de lanzamiento.
        // Si no encontramos app instalada, ofrecemos web o Play Store sin pedir contraseñas.
        for (pkg in service.packages) {
            val native = packageManager.getLeanbackLaunchIntentForPackage(pkg)
                ?: packageManager.getLaunchIntentForPackage(pkg)
            if (native != null) {
                try { startActivity(native); return }
                catch (_: Exception) { /* probar siguiente variante */ }
            }
        }
        AlertDialog.Builder(this).setTitle("${service.name} no encontrada")
            .setMessage("No detectamos la aplicación oficial compatible. Puedes abrir su sitio web o buscarla en Google Play.")
            .setPositiveButton("Abrir web") { _, _ -> openUrl(service.url) }
            .setNeutralButton("Buscar en Play Store") { _, _ ->
                val preferred = service.packages.last()
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$preferred"))) }
                catch (_: Exception) { openUrl("https://play.google.com/store/apps/details?id=$preferred") }
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun searchYouTube(query: String) {
        // URL oficial de resultados. Puede abrir YouTube o Chrome según la configuración del equipo.
        val link = "https://www.youtube.com/results?search_query=" + Uri.encode(query)
        openUrl(link)
    }

    private fun openUrl(link: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link))) }
        catch (_: Exception) { inform("No se pudo abrir", "Prueba desde la aplicación oficial o instala un navegador compatible.") }
    }
    private fun showTelevision() {
        startScreen("TV en vivo 📡", "Reproductor IPTV integrado · señal por internet")
        button("← Inicio") { showHome() }
        if (store.currentProfile != 3) {
            button("🌐 Cargar lista comunitaria de Chile") {
                AlertDialog.Builder(this).setTitle("Lista pública de Chile")
                    .setMessage("La lista iptv-org es comunitaria: no se garantiza que los enlaces funcionen ni que tengan permiso de redistribución. Utiliza solo señales cuyo acceso y reproducción estén autorizados. ¿Deseas cargarla?")
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Cargar") { _, _ ->
                        importRemote("https://iptv-org.github.io/iptv/countries/cl.m3u")
                    }.show()
            }
            button("🔗 Importar otra lista M3U (URL)") {
                inputDialog("Dirección de la lista M3U", "https://.../lista.m3u") { value ->
                    if (value.startsWith("https://") || value.startsWith("http://")) importRemote(value)
                    else inform("URL incorrecta", "Introduce un enlace HTTP o HTTPS a una lista M3U autorizada.")
                }
            }
            button("📁 Importar M3U desde un archivo") {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                try { startActivityForResult(intent, 77) }
                catch (_: Exception) { inform("No disponible", "Este dispositivo no tiene selector de archivos. Usa la opción de URL.") }
            }
        } else area.addView(text("En Peques solo aparecen los canales aprobados previamente por un adulto.", 14f, false, muted))
        val channels = store.channels()
        area.addView(text("${channels.size} canales importados${if (store.currentProfile==3) " · ${store.kidsApproved().size} aprobados" else ""}", 14f, true, lilac))
        val filter = EditText(this).apply {
            setSingleLine(true); hint = "Buscar canal o categoría"; setText(search)
            setTextColor(white); setHintTextColor(muted); textSize = 16f
            background = roundedBg(card)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    search = s?.toString() ?: ""; renderChannels()
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        area.addView(filter, LinearLayout.LayoutParams(-1, dp(55)))
        space(8)
        button("✕ Limpiar búsqueda") { filter.setText("") }
        button("☷ Categoría: $categoryFilter") {
            val available = (listOf("Todos") + store.channels().map { it.group.ifBlank { "Otros" } }.distinct().sorted()).toTypedArray()
            AlertDialog.Builder(this).setTitle("Filtrar por categoría")
                .setItems(available) { _, selected -> categoryFilter = available[selected]; showTelevision() }
                .setNegativeButton("Cancelar", null).show()
        }
        button(if (hideProblematic) "☑ Ocultando señales con problemas" else "☐ Ocultar señales marcadas con problemas") {
            hideProblematic = !hideProblematic
            showTelevision()
        }
        button(if (onlyFavorites) "★ Mostrando favoritos · ver todos" else "☆ Ver solo favoritos") {
            onlyFavorites = !onlyFavorites
            showTelevision()
        }
        listArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        area.addView(listArea)
        renderChannels()
    }
    private fun renderChannels() {
        val container = listArea ?: return
        container.removeAllViews()
        val q = search.trim()
        val favorites = store.favorites(store.currentProfile)
        val allowed = store.kidsApproved()
        val matches = store.channels().asSequence()
            .filter { store.currentProfile != 3 || it.id in allowed }
            .filter { !onlyFavorites || it.id in favorites }
            .filter { categoryFilter == "Todos" || it.group == categoryFilter }
            .filter { !hideProblematic || store.channelStatus(it.id) !in setOf("no_audio", "no_video", "unstable") }
            .filter { q.isEmpty() || it.name.contains(q, true) || it.group.contains(q, true) }
            .toList()
        if (matches.isEmpty()) {
            container.addView(text(if (store.channels().isEmpty()) "No hay canales. Importa una lista M3U para comenzar." else "Sin canales para este filtro.", 15f, false, muted))
            return
        }
        container.addView(text("${matches.size} resultados · mostrando ${minOf(matches.size, 80)}", 13f, false, muted))
        for (ch in matches.take(80)) {
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(9), dp(10), dp(9))
                background = roundedBg(card)
            }
            tile.addView(text("${if (ch.id in favorites) "★ " else ""}${ch.name}", 17f, true))
            val statusLabel = when (store.channelStatus(ch.id)) {
                "ok" -> "✓ Funciona"
                "no_audio" -> "🔇 Sin audio"
                "no_video" -> "◼ Sin imagen"
                "unstable" -> "≈ Inestable"
                else -> "Sin comprobar"
            }
            tile.addView(text("${ch.group} · $statusLabel", 12f, false, muted))
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            fun action(label: String, onClick: () -> Unit) {
                val b = makeButton(label, Color.rgb(75, 49, 110), onClick)
                val lp = LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(4) }
                actions.addView(b, lp)
            }
            action("▶ Ver") {
                startActivity(Intent(this, PlayerActivity::class.java).putExtra("url", ch.url).putExtra("title", ch.name))
            }
            action(if (ch.id in favorites) "★" else "☆") {
                store.toggleFavorite(store.currentProfile, ch.id); renderChannels()
            }
            if (store.currentProfile != 3) action(if (ch.id in allowed) "🧸 ✓" else "🧸 +") {
                if (!pins.configured) inform("Configura el PIN", "Primero configura el PIN infantil en el inicio.")
                else { store.toggleKidsApproved(ch.id); renderChannels() }
            }
            tile.addView(actions)
            if (store.currentProfile != 3) {
                val statusButton = makeButton("⚑ Marcar estado de la señal", Color.rgb(54, 38, 75)) {
                    val values = arrayOf("Sin comprobar", "✓ Funciona", "🔇 Sin audio", "◼ Sin imagen", "≈ Inestable")
                    val codes = arrayOf("", "ok", "no_audio", "no_video", "unstable")
                    AlertDialog.Builder(this).setTitle(ch.name)
                        .setItems(values) { _, idx -> store.setChannelStatus(ch.id, codes[idx]); renderChannels() }
                        .setNegativeButton("Cancelar", null).show()
                }
                tile.addView(statusButton, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(5) })
            }
            container.addView(tile, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }
        if (matches.size > 80) container.addView(text("Para ver más, escribe el nombre del canal en el buscador.", 13f, false, muted))
    }
    private fun importRemote(url: String) {
        Toast.makeText(this, "Cargando lista de canales...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15000; readTimeout = 15000
                    setRequestProperty("User-Agent", "MiTV-by-Monsant/0.8")
                }
                try {
                    if (connection.responseCode !in 200..299) throw IllegalStateException("HTTP ${connection.responseCode}")
                    val bytes = connection.inputStream.use { input ->
                        val output = java.io.ByteArrayOutputStream()
                        val buf = ByteArray(8192)
                        var total = 0
                        while (true) {
                            val n = input.read(buf)
                            if (n == -1) break
                            total += n
                            if (total > 2_500_000) throw IllegalStateException("Lista demasiado grande")
                            output.write(buf, 0, n)
                        }
                        output.toByteArray()
                    }
                    val found = M3uParser.parse(String(bytes, Charsets.UTF_8))
                    runOnUiThread { acceptImport(found) }
                } finally { connection.disconnect() }
            } catch (e: Exception) { runOnUiThread { inform("No se pudo importar", e.localizedMessage ?: "Revisa el enlace o la conexión a internet.") } }
        }.start()
    }
    private fun acceptImport(channels: List<TvChannel>) {
        if (channels.isEmpty()) { inform("Lista vacía", "No encontramos enlaces HTTP/HTTPS de canales en esa lista M3U."); return }
        AlertDialog.Builder(this).setTitle("${channels.size} canales encontrados")
            .setMessage("¿Deseas reemplazar la lista actual o sumar estos canales? Los favoritos se conservarán para los enlaces que sigan presentes.")
            .setNegativeButton("Cancelar", null)
            .setNeutralButton("Reemplazar") { _, _ -> store.saveChannels(channels); search = ""; showTelevision() }
            .setPositiveButton("Sumar") { _, _ ->
                val all = (store.channels() + channels).distinctBy { it.url }.take(1200)
                store.saveChannels(all); search = ""; showTelevision()
            }.show()
    }
    @Deprecated("Use Activity Result API in a future iteration")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77 && resultCode == RESULT_OK && data?.data != null) {
            try {
                val input = contentResolver.openInputStream(data.data!!) ?: throw IllegalStateException("No se puede abrir")
                val output = java.io.ByteArrayOutputStream()
                input.use { stream ->
                    val buffer = ByteArray(8192)
                    while (true) {
                        val n = stream.read(buffer)
                        if (n < 0) break
                        if (output.size() + n > 2_500_000) throw IllegalStateException("El archivo supera 2,5 MB")
                        output.write(buffer, 0, n)
                    }
                }
                acceptImport(M3uParser.parse(output.toString("UTF-8")))
            } catch (e: Exception) { inform("Error de importación", e.localizedMessage ?: "Archivo ilegible") }
        }
    }
    @Deprecated("Back handler simplified for initial prototype")
    override fun onBackPressed() {
        if (screen == "profiles") { super.onBackPressed(); return }
        if (screen.startsWith("Hola")) adultOnly { showProfiles() }
        else showHome()
    }
}
