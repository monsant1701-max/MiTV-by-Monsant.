package com.monsant.mitv

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class MiTVStore(context: Context) {
    private val prefs = context.getSharedPreferences("mitv_v04", Context.MODE_PRIVATE)
    var currentProfile: Int
        get() = prefs.getInt("current_profile", 0)
        set(v) { prefs.edit().putInt("current_profile", v).apply() }
    fun profileName(index: Int): String = prefs.getString("profile_name_$index", if (index == 3) "Peques" else "Perfil ${index+1}") ?: "Perfil ${index+1}"
    fun setProfileName(index: Int, value: String) { prefs.edit().putString("profile_name_$index", value).apply() }
    fun avatar(index: Int): String = prefs.getString("avatar_$index", listOf("Monse", "Anto", "Giss", "Kiara")[index]) ?: "Monse"
    fun setAvatar(index: Int, value: String) { prefs.edit().putString("avatar_$index", value).apply() }
    fun channels(): List<TvChannel> {
        return try {
            val array = JSONArray(prefs.getString("channels", "[]"))
            (0 until array.length()).map { i ->
                val item = array.getJSONObject(i)
                TvChannel(item.getString("name"), item.getString("url"), item.optString("group", "Otros"), item.optString("logo", ""))
            }
        } catch (_: Exception) { emptyList() }
    }
    fun saveChannels(items: List<TvChannel>) {
        val array = JSONArray()
        items.forEach { array.put(JSONObject().put("name", it.name).put("url", it.url).put("group", it.group).put("logo", it.logo)) }
        prefs.edit().putString("channels", array.toString()).apply()
    }
    fun favorites(index: Int): Set<String> = prefs.getStringSet("fav_$index", emptySet())?.toSet() ?: emptySet()
    fun toggleFavorite(index: Int, id: String) {
        val next = favorites(index).toMutableSet()
        if (!next.add(id)) next.remove(id)
        prefs.edit().putStringSet("fav_$index", next).apply()
    }
    fun kidsApproved(): Set<String> = prefs.getStringSet("kids_approved", emptySet())?.toSet() ?: emptySet()
    fun toggleKidsApproved(id: String) {
        val next = kidsApproved().toMutableSet()
        if (!next.add(id)) next.remove(id)
        prefs.edit().putStringSet("kids_approved", next).apply()
    }
    /** Estado manual de la señal: no se deduce automáticamente de un stream. */
    fun channelStatus(id: String): String = prefs.getString(statusKey(id), "") ?: ""
    fun setChannelStatus(id: String, status: String) {
        val allowed = setOf("", "ok", "no_audio", "no_video", "unstable")
        if (status !in allowed) return
        prefs.edit().putString(statusKey(id), status).apply()
    }
    private fun statusKey(id: String): String {
        val digest = java.security.MessageDigest.getInstance("SHA-256")
            .digest(id.toByteArray(Charsets.UTF_8))
        return "health_" + digest.take(12).joinToString("") { "%02x".format(it) }
    }
    fun platformEnabled(name: String, index: Int): Boolean = prefs.getBoolean("platform_${index}_$name", name != "Rakuten Viki")
    fun setPlatformEnabled(name: String, index: Int, value: Boolean) { prefs.edit().putBoolean("platform_${index}_$name", value).apply() }
}
