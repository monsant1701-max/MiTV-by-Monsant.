package com.monsant.mitv

import android.content.Context
import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Protección local básica; para controles parentales completos también configurar los servicios oficiales. */
class PinManager(context: Context) {
    private val prefs = context.getSharedPreferences("mitv_pin", Context.MODE_PRIVATE)
    val configured: Boolean get() = prefs.contains("hash")
    fun create(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = derive(pin, salt)
        prefs.edit().putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("hash", Base64.encodeToString(hash, Base64.NO_WRAP)).apply()
    }
    fun check(pin: String): Boolean = try {
        val salt = Base64.decode(prefs.getString("salt", ""), Base64.NO_WRAP)
        val reference = Base64.decode(prefs.getString("hash", ""), Base64.NO_WRAP)
        java.security.MessageDigest.isEqual(reference, derive(pin, salt))
    } catch (_: Exception) { false }
    private fun derive(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 100_000, 256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword() }
    }
}
