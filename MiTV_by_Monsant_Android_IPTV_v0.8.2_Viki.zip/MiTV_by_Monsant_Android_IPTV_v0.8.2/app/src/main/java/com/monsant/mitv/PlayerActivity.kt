package com.monsant.mitv

import android.app.Activity
import android.app.AlertDialog
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

/** Reproducción de señales permitidas. Diagnóstico: no inventa audio ausente. */
class PlayerActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var message: TextView
    private lateinit var header: LinearLayout
    private lateinit var status: TextView
    private lateinit var controls: LinearLayout
    private lateinit var store: MiTVStore
    private val handler = Handler(Looper.getMainLooper())
    private var timeoutCheck: Runnable? = null
    private var hideControls: Runnable? = null
    private val channelUrl: String get() = intent.getStringExtra("url") ?: ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = MiTVStore(this)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        volumeControlStream = AudioManager.STREAM_MUSIC
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        val frame = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        playerView = PlayerView(this).apply {
            useController = true
            controllerShowTimeoutMs = 4500
            keepScreenOn = true
            isFocusable = true
        }
        frame.addView(playerView, FrameLayout.LayoutParams(-1, -1))

        header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 5, 12, 5)
            setBackgroundColor(0xC4171028.toInt())
        }
        header.addView(TextView(this).apply {
            text = (intent.getStringExtra("title") ?: "TV en vivo") + " · MiTV 0.7"
            textSize = 13f
            setTextColor(0xFFEEDFFF.toInt())
        })
        message = TextView(this).apply {
            text = "Conectando con la señal…"
            textSize = 12f
            setTextColor(0xFFFFE6B0.toInt())
        }
        header.addView(message)
        status = TextView(this).apply {
            textSize = 11f
            setTextColor(0xFFD7C3F3.toInt())
        }
        header.addView(status)
        frame.addView(header, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(6, 2, 6, 2)
            setBackgroundColor(0xD8170F2A.toInt())
        }
        fun addRow(vararg buttons: Pair<String, () -> Unit>) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for ((label, action) in buttons) {
                val button = Button(this).apply {
                    text = label
                    isAllCaps = false
                    textSize = 11f
                    minHeight = 0
                    minimumHeight = 0
                    setPadding(2, 0, 2, 0)
                    isFocusable = true
                    setOnClickListener { action(); showControlsTemporarily() }
                }
                row.addView(button, LinearLayout.LayoutParams(0, 43, 1f))
            }
            controls.addView(row)
        }
        addRow(
            "↻ Reintentar" to { startPlayer() },
            "♫ Audio / Pistas" to { chooseAudioTrack() },
            "🔊 Volumen" to { showVolumeControl() },
            "ⓘ Diagnóstico" to { audioDiagnostic() },
            "← Volver" to { finish() }
        )
        addRow(
            "✓ Funciona" to { mark("ok") },
            "🔇 Sin audio" to { mark("no_audio") },
            "◼ Sin imagen" to { mark("no_video") },
            "≈ Se corta" to { mark("unstable") },
            "Ocultar" to { controls.visibility = View.GONE; header.visibility = View.GONE }
        )
        frame.addView(controls, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(frame)
        // Tocar el encabezado permite recuperar el menú tras ocultarlo.
        header.setOnClickListener { showControlsTemporarily() }
        playerView.setOnTouchListener { _, event ->
            if (event.action == android.view.MotionEvent.ACTION_UP && controls.visibility != View.VISIBLE) {
                showControlsTemporarily()
            }
            false
        }
        updateStatus()
    }

    private fun showControlsTemporarily() {
        controls.visibility = View.VISIBLE
        header.visibility = View.VISIBLE
        hideControls?.let { handler.removeCallbacks(it) }
        val task = Runnable { controls.visibility = View.GONE; if (player?.playbackState == Player.STATE_READY) header.visibility = View.GONE }
        hideControls = task
        handler.postDelayed(task, 11000)
    }

    private fun mark(value: String) {
        if (channelUrl.isBlank()) return
        store.setChannelStatus(channelUrl, value)
        updateStatus()
        Toast.makeText(this, "Estado guardado (no modifica la señal)", Toast.LENGTH_SHORT).show()
    }

    private fun updateStatus() {
        status.text = when (store.channelStatus(channelUrl)) {
            "ok" -> "Marcado: funciona bien ✓"
            "no_audio" -> "Marcado: imagen sin sonido 🔇"
            "no_video" -> "Marcado: sin imagen ◼"
            "unstable" -> "Marcado: señal inestable ≈"
            else -> "Marca el estado de esta señal si hace falta"
        }
    }

    private fun audioGroups(): List<Tracks.Group> = player?.currentTracks?.groups
        ?.filter { it.type == C.TRACK_TYPE_AUDIO } ?: emptyList()

    private fun audioSummary(): String {
        val exo = player ?: return "Reproductor no iniciado."
        val groups = audioGroups()
        if (exo.playbackState == Player.STATE_IDLE || exo.playbackState == Player.STATE_BUFFERING) {
            return "La señal todavía está cargando; revisa nuevamente cuando haya imagen."
        }
        if (groups.isEmpty()) return "No se detectaron pistas de audio en la señal. MiTV no puede crear sonido si la fuente no lo envía."
        val options = groups.sumOf { it.length }
        val supported = groups.sumOf { g -> (0 until g.length).count { g.isTrackSupported(it) } }
        val selected = groups.sumOf { g -> (0 until g.length).count { g.isTrackSelected(it) } }
        return "Pistas: $options; compatibles: $supported; seleccionadas: $selected. " +
            if (supported == 0) "El dispositivo no admite las pistas detectadas." else
                if (selected == 0) "Ninguna pista elegida; abre Audio / Pistas." else "Si sigue mudo, prueba otra pista o revisa el sonido del dispositivo."
    }

    private fun audioDiagnostic() {
        val manager = getSystemService(AUDIO_SERVICE) as AudioManager
        val current = manager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = manager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val details = audioGroups().flatMap { group ->
            (0 until group.length).map { i ->
                val format = group.getTrackFormat(i)
                "• ${format.language ?: "Idioma sin identificar"} · ${format.sampleMimeType ?: "Formato sin identificar"}" +
                    " · ${if (group.isTrackSupported(i)) "compatible" else "no compatible"}" +
                    if (group.isTrackSelected(i)) " · seleccionada" else ""
            }
        }.joinToString("\n")
        AlertDialog.Builder(this).setTitle("Diagnóstico de audio")
            .setMessage("Volumen multimedia: $current/$max\n\n${audioSummary()}" +
                if (details.isEmpty()) "" else "\n\n$details" +
                "\n\nEl diagnóstico no puede confirmar si la señal transmite audio silencioso.")
            .setNegativeButton("Cerrar", null)
            .setPositiveButton("Elegir pista") { _, _ -> chooseAudioTrack() }
            .setNeutralButton("Probar altavoz") { _, _ -> testDeviceAudio() }
            .show()
    }

    private fun showVolumeControl() {
        val manager = getSystemService(AUDIO_SERVICE) as AudioManager
        manager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI)
        Toast.makeText(this, "Usa los botones de volumen del celular o el control del TV", Toast.LENGTH_LONG).show()
    }

    private fun testDeviceAudio() {
        // Pitido del dispositivo: prueba únicamente altavoz/volumen, no el audio de la señal.
        try {
            val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 85)
            tone.startTone(ToneGenerator.TONE_PROP_BEEP, 350)
            handler.postDelayed({ tone.release() }, 700)
            Toast.makeText(this, "Si escuchaste el pitido, el altavoz funciona", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "No se pudo ejecutar la prueba del altavoz", Toast.LENGTH_LONG).show()
        }
    }

    private fun chooseAudioTrack() {
        val exo = player ?: return
        val groups = audioGroups()
        if (groups.isEmpty()) {
            AlertDialog.Builder(this).setTitle("Sin pistas de audio")
                .setMessage(audioSummary()).setPositiveButton("Entendido", null).show()
            return
        }
        val items = mutableListOf("Automático (selección del reproductor)")
        val refs = mutableListOf<Pair<Tracks.Group, Int>>()
        groups.forEach { group ->
            for (i in 0 until group.length) {
                val f = group.getTrackFormat(i)
                items += "${f.language ?: "Audio"} · ${f.sampleMimeType ?: "desconocido"}" +
                    " (${if (group.isTrackSupported(i)) "compatible" else "incompatible"})" +
                    if (group.isTrackSelected(i)) " ✓" else ""
                refs += group to i
            }
        }
        AlertDialog.Builder(this).setTitle("Elegir pista de audio")
            .setItems(items.toTypedArray()) { _, which ->
                val params = exo.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                    .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                if (which > 0) {
                    val (group, index) = refs[which - 1]
                    if (!group.isTrackSupported(index)) {
                        Toast.makeText(this, "Este dispositivo no admite esa pista", Toast.LENGTH_LONG).show()
                        return@setItems
                    }
                    params.addOverride(TrackSelectionOverride(group.mediaTrackGroup, index))
                }
                exo.trackSelectionParameters = params.build()
                Toast.makeText(this, "Pista de audio actualizada", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null).show()
    }

    override fun onStart() {
        super.onStart()
        startPlayer()
    }

    private fun startPlayer() {
        timeoutCheck?.let { handler.removeCallbacks(it) }
        playerView.player = null
        player?.release()
        player = null
        if (channelUrl.isBlank()) { message.text = "No se recibió un enlace de canal."; return }
        message.text = "Conectando con la señal…"
        val exo = ExoPlayer.Builder(this).build()
        exo.setAudioAttributes(
            AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),
            true
        )
        exo.volume = 1f
        player = exo
        playerView.player = exo
        val builder = MediaItem.Builder().setUri(channelUrl)
        val path = channelUrl.substringBefore('?')
        if (path.endsWith(".m3u8", true) ||
            !path.matches(Regex(".*\\.(mp4|mpd|ts|mp3|aac)$", RegexOption.IGNORE_CASE))) {
            builder.setMimeType(MimeTypes.APPLICATION_M3U8)
        }
        exo.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_READY -> {
                        message.text = "Señal conectada. Audio: ${audioGroups().size} grupo(s)."
                        showControlsTemporarily()
                    }
                    Player.STATE_BUFFERING -> message.text = "Cargando video…"
                    Player.STATE_ENDED -> message.text = "La transmisión terminó. Prueba reintentar."
                }
            }
            override fun onTracksChanged(tracks: Tracks) {
                if (exo.playbackState == Player.STATE_READY) message.text = audioSummary()
            }
            override fun onPlayerError(error: PlaybackException) {
                message.text = "No se pudo reproducir la señal (${error.errorCodeName}). Prueba reintentar o regresar."
                showControlsTemporarily()
            }
        })
        exo.setMediaItem(builder.build())
        exo.prepare()
        exo.playWhenReady = true
        showControlsTemporarily()
        val check = Runnable {
            if (player === exo && exo.playbackState != Player.STATE_READY) {
                message.text = "La señal no inicia. Quizá está caída, restringida o es incompatible."
                showControlsTemporarily()
            }
        }
        timeoutCheck = check
        handler.postDelayed(check, 18000L)
    }

    override fun onStop() {
        timeoutCheck?.let { handler.removeCallbacks(it) }; timeoutCheck = null
        hideControls?.let { handler.removeCallbacks(it) }; hideControls = null
        playerView.player = null
        player?.release(); player = null
        super.onStop()
    }
}
